<!-- Start with image -->
<div class="container">
      <div class="wrapper about-us">
            <!-- start form -->
            <div class="content">
                  <h1>Who Are We? </h1>
                  <p class="lead text-white">We are Four IT student who decided to make an anti-phishing extension which is RockGuard,
                        our "phishing detection tool" is a technological solution designed to combat the ever-growing threat of phishing attacks.
                  </p>
                  <p class="lead text-white">Our primary function is to identify and alert users about potentially fraudulent websites</p>
            </div>

            <div class="image-area">
                  <img class="img-fluid" src="./images/login-image.png" alt="image">
            </div>
      </div>
</div>