<div class="wrapper-sign">
      <!-- Start with image -->
      <div class="container">
            <div class="sign-in">
                  <div class="image-area">
                        <img class="img-fluid" src="./images/login-image.png" alt="image">
                  </div>
                  <!-- start form -->
                  <div class="form-area">
                        <h2 class="text-center">Forgot Password ?</h2>
                        <span>New Password</span>
                        <!-- start form-->
                        <form action="">
                              <div class="form-group">
                                    <label for="email">EMAIL</label>
                                    <input class="form-control" type="email" id="email" name="email" placeholder="Enter Email">
                              </div>
                              <div class="form-group text-center mt-4 w-100">
                                    <button class="btn btn-register text-white mr-0 mr-md-2 mb-2 mr-md-0 d-block w-100 mt-2 d-block w-100" type="submit">Send</button>
                              </div>
                        </form>
                        <!-- end form-->
                  </div>
            </div>
      </div>
</div>