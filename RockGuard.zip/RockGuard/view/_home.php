<?php

?>
<!-- Start with image -->
<div class="wrapper-home">
      <div class="container">
            <div class="home">
                  <!--Logo -->
                  <div class="logo">
                        <img class="img-fluid" src="./images/3_copy.png" alt="image">
                  </div>
                  <!-- content -->
                  <div class="content">
                        <div class="rock-ground">
                              <img class="img-fluid" src="./images/group_4.png" alt="image">
                        </div>
                        <div class="download-extension w-50 mt-5">
                        <a href="RockGuard.zip"><img class="img-fluid ml-5" src="./images/download extension.png" alt="image"></a>
                        </div>
                  </div>
            </div>
      </div>
</div>